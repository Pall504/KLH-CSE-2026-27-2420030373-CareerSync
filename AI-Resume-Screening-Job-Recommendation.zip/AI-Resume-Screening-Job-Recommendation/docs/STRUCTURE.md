# Repository Structure Guide

- `src/` — source code and application modules.
- `docs/` — technical/project documentation.
- `data/` — datasets, or documented references to external data sources.
- `results/` — generated outputs, predictions, evaluation results, and visualizations.
- `reports/` — phase/review reports and final report material.
- `README.md` — mandatory project information, setup, execution, team, supervisor, abstract, and phase status.
